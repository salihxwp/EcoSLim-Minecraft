package com.ecosim.fabric;

import net.fabricmc.api.ModInitializer;

public class EcoSimFabric implements ModInitializer {
    public static final String MOD_ID = "ecosim";

    @Override
    public void onInitialize() {
        System.out.println("EcoSim Fabric bootstrap initialized");
    }
}
