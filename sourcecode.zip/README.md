# EcoSim

EcoSim is a modular ecosystem simulation project built with Java and Gradle. The shared simulation engine is implemented in the common module, while Fabric and NeoForge are separated into loader-specific adapters.

## Status

- Common simulation engine: implemented and tested
- Fabric bootstrap: configured
- NeoForge: scaffolded as a placeholder module until a compatible loader setup is validated
- Forge: not yet enabled for the selected target version

## Build

From the project root:

```bash
gradle :ecosim-common:test
```

The project uses a local Gradle 8.10.2 toolchain installed under the workspace for compatibility with Fabric Loom.

## Compatible versions

- Java: 21
- Minecraft target: 1.21.1
- Fabric: Loom 1.7.4 / Loader 0.16.5
- NeoForge: scaffolded only; full NeoForge integration remains pending verification

## Notes

This repository intentionally keeps the simulation logic in the common module without directly importing Minecraft classes, Fabric APIs, Forge APIs, or NeoForge APIs.
