package com.ecosim.neoforge;

import net.neoforged.fml.common.Mod;

@Mod(EcoSimNeoForge.MOD_ID)
public final class EcoSimNeoForge {
    public static final String MOD_ID = "ecosim";

    public EcoSimNeoForge() {
        System.out.println("EcoSim NeoForge bootstrap initialized");
    }
}
