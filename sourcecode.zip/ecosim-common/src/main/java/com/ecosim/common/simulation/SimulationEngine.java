package com.ecosim.common.simulation;

import com.ecosim.common.model.HabitatState;
import com.ecosim.common.model.RegionId;
import com.ecosim.common.species.SpeciesDefinition;
import com.ecosim.common.species.SpeciesRegistry;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.SplittableRandom;

public class SimulationEngine {
    private final SimulationConfig config;
    private final SplittableRandom random;

    public SimulationEngine() {
        this(SimulationConfig.defaults());
    }

    public SimulationEngine(SimulationConfig config) {
        this(config, new SplittableRandom(config.seed()));
    }

    public SimulationEngine(SimulationConfig config, long seed) {
        this.config = config;
        this.random = new SplittableRandom(seed);
    }

    public SimulationEngine(SimulationConfig config, SplittableRandom random) {
        this.config = config;
        this.random = random == null ? new SplittableRandom(config.seed()) : random;
    }

    public HabitatState step(HabitatState habitat, SpeciesRegistry speciesRegistry, long elapsedTicks) {
        HabitatState next = habitat.copy();
        Map<String, Double> populations = new LinkedHashMap<>(next.speciesPopulations());
        Map<String, SpeciesDefinition> defs = speciesRegistry.getDefinitions();

        double vegetation = clamp(next.vegetationBiomass(), 0.0, 100.0);
        double recoveryBoost = (next.water() > 0.15 ? next.water() : 0.0) * config.vegetationRecoveryRate();
        double herbivorePressure = populations.getOrDefault("rabbit", 0.0) * 0.02 + populations.getOrDefault("deer", 0.0) * 0.03;
        vegetation = Math.min(100.0, vegetation + recoveryBoost * Math.max(1.0, elapsedTicks / 10.0));
        vegetation = Math.max(0.0, vegetation - herbivorePressure * 0.8);

        for (String speciesId : defs.keySet()) {
            SpeciesDefinition species = defs.get(speciesId);
            double currentPopulation = populations.getOrDefault(speciesId, 0.0);
            if (currentPopulation <= 0.0 && !"wild_bee".equals(speciesId)) {
                continue;
            }
            double resourceFactor = resourceFactor(species, next, vegetation);
            double growth = species.reproductionRate() * currentPopulation * (1.0 - currentPopulation / species.localPopulationCapacity())
                    * resourceFactor;
            double mortality = species.mortalityRate() * currentPopulation * (1.0 - resourceFactor);
            if (Math.abs(growth) < config.minPopulationGrowthThreshold()) {
                growth = 0.0;
            }
            double target = currentPopulation + growth - mortality;
            if (species.trophicRole() == SpeciesDefinition.TrophicRole.PREDATOR || species.trophicRole() == SpeciesDefinition.TrophicRole.OMNIVORE) {
                target -= predationLoss(speciesId, populations, speciesRegistry) * config.predationStrength();
            }
            if (species.trophicRole() == SpeciesDefinition.TrophicRole.HERBIVORE) {
                target -= vegetationLossForGrazing(currentPopulation, vegetation) * 0.2;
            }
            target = Math.max(0.0, Math.min(species.localPopulationCapacity() * config.populationCapScale(), target));
            populations.put(speciesId, target);
        }

        Map<String, Double> prey = new LinkedHashMap<>();
        prey.put("rabbit", populations.getOrDefault("rabbit", 0.0));
        prey.put("deer", populations.getOrDefault("deer", 0.0));
        double foxPredation = Math.min(prey.getOrDefault("rabbit", 0.0) * 0.06, populations.getOrDefault("fox", 0.0) * 0.14);
        double wolfPredation = Math.min(prey.getOrDefault("deer", 0.0) * 0.05 + prey.getOrDefault("rabbit", 0.0) * 0.04, populations.getOrDefault("wolf", 0.0) * 0.15);
        double foxPressure = populations.getOrDefault("fox", 0.0) * 0.5;
        double wolfPressure = populations.getOrDefault("wolf", 0.0) * 0.7;
        populations.put("rabbit", Math.max(0.0, populations.getOrDefault("rabbit", 0.0) - foxPredation * 0.7 - wolfPredation * 0.3 - foxPressure * 0.15 - wolfPressure * 0.12));
        populations.put("deer", Math.max(0.0, populations.getOrDefault("deer", 0.0) - wolfPredation * 0.7 - foxPressure * 0.1 - wolfPressure * 0.18));
        populations.put("fox", Math.max(0.0, populations.getOrDefault("fox", 0.0) + foxPredation * 0.18));
        populations.put("wolf", Math.max(0.0, populations.getOrDefault("wolf", 0.0) + wolfPredation * 0.22));

        populations.put("wild_bee", Math.max(0.0, populations.getOrDefault("wild_bee", 0.0) * (1.0 + config.vegetationRecoveryRate() * 0.3)));

        applyPopulationCaps(populations, defs);
        Map<String, Double> migrated = migratePopulation(populations, config.migrationRate(), random);
        applyPopulationCaps(migrated, defs);
        HabitatState result = new HabitatState(
                next.regionId(),
                clamp(vegetation, 0.0, 100.0),
                clamp(next.water() + (0.02 * Math.max(0.0, 1.0 - next.humanDisturbance())), 0.0, 1.0),
                clamp(next.shelter() + (0.01 * next.forestCover()), 0.0, 1.0),
                clamp(next.forestCover() + (0.005 * (1.0 - next.humanDisturbance())), 0.0, 1.0),
                clamp(next.humanDisturbance() + 0.005, 0.0, 1.0),
                migrated,
                elapsedTicks,
                clamp(next.recoveryState() + 0.02, 0.0, 1.0)
        );

        return result;
    }

    public static double grazingPressure(HabitatState habitat) {
        return Math.max(0.0, habitat.vegetationBiomass() / 100.0) * (1.0 - habitat.water());
    }

    public static Map<String, Double> migratePopulation(Map<String, Double> populations, double migrationRate, SplittableRandom random) {
        Map<String, Double> migrated = new LinkedHashMap<>();
        double total = 0.0;
        for (Map.Entry<String, Double> entry : populations.entrySet()) {
            total += entry.getValue();
        }
        double totalAfter = 0.0;
        for (Map.Entry<String, Double> entry : populations.entrySet()) {
            double value = entry.getValue();
            double moved = value * migrationRate * (0.1 + random.nextDouble(0.0, 0.2));
            double remainder = value - moved;
            migrated.put(entry.getKey(), remainder);
            totalAfter += remainder;
        }
        if (total > 0.0 && totalAfter >= 0.0) {
            double adjustment = total - totalAfter;
            String first = migrated.keySet().iterator().next();
            migrated.put(first, migrated.get(first) + adjustment);
        }
        return migrated;
    }

    private double resourceFactor(SpeciesDefinition species, HabitatState habitat, double vegetation) {
        double waterFactor = Math.max(0.0, habitat.water() / Math.max(0.1, species.waterRequirement()));
        double vegetationFactor = Math.max(0.0, vegetation / 100.0);
        double shelterFactor = habitat.shelter();
        double habitatFactor = clamp(species.habitatSuitability() * 0.5 + waterFactor * 0.3 + shelterFactor * 0.2, 0.0, 1.0);
        if (species.trophicRole() == SpeciesDefinition.TrophicRole.PREDATOR || species.trophicRole() == SpeciesDefinition.TrophicRole.OMNIVORE) {
            if (habitat.speciesPopulations().isEmpty()) {
                return 0.25;
            }
            return clamp((habitatFactor + vegetationFactor) / 2.0, 0.0, 1.0);
        }
        if (species.trophicRole() == SpeciesDefinition.TrophicRole.PRODUCER) {
            return clamp(0.4 + vegetationFactor + habitatFactor, 0.0, 1.0);
        }
        return clamp(0.5 * habitatFactor + 0.5 * vegetationFactor, 0.0, 1.0);
    }

    private double predationLoss(String predatorId, Map<String, Double> populations, SpeciesRegistry speciesRegistry) {
        SpeciesDefinition predator = speciesRegistry.get(predatorId);
        if (predator == null) {
            return 0.0;
        }
        double loss = 0.0;
        for (String preyId : predator.foodPreferences()) {
            double preyPopulation = populations.getOrDefault(preyId, 0.0);
            if (preyPopulation <= 0.0) {
                continue;
            }
            double pressure = (populations.getOrDefault(predatorId, 0.0) * preyPopulation) / Math.max(1.0, predator.localPopulationCapacity());
            loss += pressure * 0.08;
        }
        return Math.min(loss, 50.0);
    }

    private double vegetationLossForGrazing(double population, double vegetation) {
        return population * (1.0 - Math.min(1.0, vegetation / 100.0)) * 0.12;
    }

    private void applyPopulationCaps(Map<String, Double> populations, Map<String, SpeciesDefinition> defs) {
        for (Map.Entry<String, Double> entry : populations.entrySet()) {
            SpeciesDefinition species = defs.get(entry.getKey());
            if (species == null) {
                continue;
            }
            double capped = Math.max(0.0, Math.min(species.localPopulationCapacity() * config.populationCapScale(), entry.getValue()));
            entry.setValue(capped);
        }
    }

    private static double clamp(double value, double min, double max) {
        if (Double.isNaN(value)) {
            return min;
        }
        return Math.max(min, Math.min(max, value));
    }

    public List<RegionId> prioritizeRegions(List<RegionId> regions) {
        if (regions == null || regions.isEmpty()) {
            return Collections.emptyList();
        }
        List<RegionId> sorted = new ArrayList<>(regions);
        sorted.sort((a, b) -> Integer.compare(Math.abs(a.x()) + Math.abs(a.z()), Math.abs(b.x()) + Math.abs(b.z())));
        return sorted.subList(0, Math.min(config.maxRegionsPerTick(), sorted.size()));
    }
}
