package com.ecosim.common.simulation;

public record SimulationConfig(
        long simulationIntervalTicks,
        long habitatSamplingIntervalTicks,
        int maxRegionsPerTick,
        int maxVisibleEntitiesPerSpecies,
        double vegetationRecoveryRate,
        double migrationRate,
        double predationStrength,
        double diseaseSimulation,
        int seed,
        double populationCapScale,
        double minPopulationGrowthThreshold
) {
    public SimulationConfig {
        simulationIntervalTicks = Math.max(1L, simulationIntervalTicks);
        habitatSamplingIntervalTicks = Math.max(1L, habitatSamplingIntervalTicks);
        maxRegionsPerTick = Math.max(1, maxRegionsPerTick);
        maxVisibleEntitiesPerSpecies = Math.max(1, maxVisibleEntitiesPerSpecies);
        vegetationRecoveryRate = clamp(vegetationRecoveryRate, 0.0, 1.0);
        migrationRate = clamp(migrationRate, 0.0, 1.0);
        predationStrength = clamp(predationStrength, 0.0, 1.0);
        diseaseSimulation = clamp(diseaseSimulation, 0.0, 1.0);
        populationCapScale = Math.max(1.0, populationCapScale);
        minPopulationGrowthThreshold = clamp(minPopulationGrowthThreshold, 0.0, 1.0);
    }

    public static SimulationConfig defaults() {
        return new SimulationConfig(200L, 600L, 8, 32, 0.08, 0.12, 0.14, 0.05, 1337, 1.0, 0.01);
    }

    private static double clamp(double value, double min, double max) {
        if (Double.isNaN(value)) {
            return min;
        }
        return Math.max(min, Math.min(max, value));
    }
}
