package com.ecosim.common.model;

public record RegionId(int x, int z) {
    public static final int REGION_SIZE = 64;

    public RegionId {
        if (Integer.MIN_VALUE == x && Integer.MIN_VALUE == z) {
            throw new IllegalArgumentException("Region coordinates cannot be null-like.");
        }
    }

    public static RegionId fromWorldBlock(int blockX, int blockZ) {
        return new RegionId(Math.floorDiv(blockX, REGION_SIZE), Math.floorDiv(blockZ, REGION_SIZE));
    }

    public int minBlockX() {
        return x * REGION_SIZE;
    }

    public int minBlockZ() {
        return z * REGION_SIZE;
    }

    public int maxBlockX() {
        return minBlockX() + REGION_SIZE - 1;
    }

    public int maxBlockZ() {
        return minBlockZ() + REGION_SIZE - 1;
    }

    public String key() {
        return x + ":" + z;
    }
}
