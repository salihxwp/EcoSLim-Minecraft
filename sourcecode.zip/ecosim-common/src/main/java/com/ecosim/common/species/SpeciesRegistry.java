package com.ecosim.common.species;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

public final class SpeciesRegistry {
    private final Map<String, SpeciesDefinition> definitions;

    public SpeciesRegistry(Map<String, SpeciesDefinition> definitions) {
        Objects.requireNonNull(definitions, "Definitions cannot be null");
        this.definitions = Collections.unmodifiableMap(new LinkedHashMap<>(definitions));
        this.definitions.values().forEach(this::validateDefinition);
    }

    public static SpeciesRegistry defaultRegistry() {
        Map<String, SpeciesDefinition> defs = new LinkedHashMap<>();
        defs.put("rabbit", new SpeciesDefinition("rabbit", "Rabbit", SpeciesDefinition.TrophicRole.HERBIVORE,
                Set.of("grass", "wildflower"), 0.75, 0.55, 0.26, 0.12, 0.70, 180.0, 0.18, 2.0, 0.08, 0.04));
        defs.put("deer", new SpeciesDefinition("deer", "Deer", SpeciesDefinition.TrophicRole.HERBIVORE,
                Set.of("grass", "shrub", "forest"), 0.82, 0.60, 0.20, 0.10, 0.76, 240.0, 0.15, 3.0, 0.12, 0.03));
        defs.put("fox", new SpeciesDefinition("fox", "Fox", SpeciesDefinition.TrophicRole.OMNIVORE,
                Set.of("rabbit", "deer", "berry"), 0.90, 0.70, 0.18, 0.15, 0.68, 120.0, 0.14, 2.0, 0.10, 0.04));
        defs.put("wolf", new SpeciesDefinition("wolf", "Wolf", SpeciesDefinition.TrophicRole.PREDATOR,
                Set.of("deer", "rabbit", "fox"), 0.95, 0.80, 0.16, 0.13, 0.72, 140.0, 0.12, 2.5, 0.15, 0.03));
        defs.put("wild_bee", new SpeciesDefinition("wild_bee", "Wild Bee", SpeciesDefinition.TrophicRole.POLLINATOR,
                Set.of("flower", "wildflower"), 0.70, 0.50, 0.27, 0.09, 0.88, 90.0, 0.22, 2.0, 0.20, 0.05));
        return new SpeciesRegistry(defs);
    }

    public Map<String, SpeciesDefinition> getDefinitions() {
        return definitions;
    }

    public SpeciesDefinition get(String id) {
        return definitions.get(id);
    }

    public void validateDefinition(SpeciesDefinition definition) {
        Objects.requireNonNull(definition, "Definition is null");
        if (!definition.id().matches("[a-z0-9_]+")) {
            throw new IllegalArgumentException("Species IDs must be lowercase and snake-case: " + definition.id());
        }
        if (definition.localPopulationCapacity() <= 0) {
            throw new IllegalArgumentException("Species capacity must be positive for " + definition.id());
        }
    }
}
