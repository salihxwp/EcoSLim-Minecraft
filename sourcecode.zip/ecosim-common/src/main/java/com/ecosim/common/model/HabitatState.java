package com.ecosim.common.model;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Properties;
import java.util.stream.Collectors;

public record HabitatState(
        RegionId regionId,
        double vegetationBiomass,
        double water,
        double shelter,
        double forestCover,
        double humanDisturbance,
        Map<String, Double> speciesPopulations,
        long lastSimulatedTick,
        double recoveryState
) {
    public HabitatState {
        regionId = regionId == null ? new RegionId(0, 0) : regionId;
        vegetationBiomass = clamp(vegetationBiomass, 0.0, 100.0);
        water = clamp(water, 0.0, 1.0);
        shelter = clamp(shelter, 0.0, 1.0);
        forestCover = clamp(forestCover, 0.0, 1.0);
        humanDisturbance = clamp(humanDisturbance, 0.0, 1.0);
        recoveryState = clamp(recoveryState, 0.0, 1.0);
        speciesPopulations = normalizePopulations(speciesPopulations);
    }

    public static HabitatState empty(RegionId regionId) {
        return new HabitatState(regionId, 0.0, 0.0, 0.0, 0.0, 0.0, Collections.emptyMap(), 0L, 0.0);
    }

    public HabitatState withUpdatedPopulation(String speciesId, double newValue) {
        Map<String, Double> next = new LinkedHashMap<>(speciesPopulations);
        next.put(speciesId, clampPopulation(newValue));
        return new HabitatState(regionId, vegetationBiomass, water, shelter, forestCover, humanDisturbance, next, lastSimulatedTick, recoveryState);
    }

    public double populationFor(String speciesId) {
        return speciesPopulations.getOrDefault(speciesId, 0.0);
    }

    public HabitatState withLastSimulatedTick(long tick) {
        return new HabitatState(regionId, vegetationBiomass, water, shelter, forestCover, humanDisturbance, speciesPopulations, tick, recoveryState);
    }

    public HabitatState copy() {
        return new HabitatState(regionId, vegetationBiomass, water, shelter, forestCover, humanDisturbance, new LinkedHashMap<>(speciesPopulations), lastSimulatedTick, recoveryState);
    }

    public Properties toProperties() {
        Properties props = new Properties();
        props.setProperty("region.x", Integer.toString(regionId.x()));
        props.setProperty("region.z", Integer.toString(regionId.z()));
        props.setProperty("vegetationBiomass", Double.toString(vegetationBiomass));
        props.setProperty("water", Double.toString(water));
        props.setProperty("shelter", Double.toString(shelter));
        props.setProperty("forestCover", Double.toString(forestCover));
        props.setProperty("humanDisturbance", Double.toString(humanDisturbance));
        props.setProperty("lastSimulatedTick", Long.toString(lastSimulatedTick));
        props.setProperty("recoveryState", Double.toString(recoveryState));
        for (Map.Entry<String, Double> entry : speciesPopulations.entrySet()) {
            props.setProperty("species." + entry.getKey(), Double.toString(entry.getValue()));
        }
        return props;
    }

    public static HabitatState fromProperties(Properties props) {
        int x = Integer.parseInt(props.getProperty("region.x", "0"));
        int z = Integer.parseInt(props.getProperty("region.z", "0"));
        Map<String, Double> species = props.stringPropertyNames().stream()
                .filter(name -> name.startsWith("species."))
                .collect(Collectors.toMap(
                        name -> name.substring("species.".length()),
                        name -> clampPopulation(Double.parseDouble(props.getProperty(name, "0"))),
                        (a, b) -> b,
                        LinkedHashMap::new
                ));

        return new HabitatState(
                new RegionId(x, z),
                Double.parseDouble(props.getProperty("vegetationBiomass", "0.0")),
                Double.parseDouble(props.getProperty("water", "0.0")),
                Double.parseDouble(props.getProperty("shelter", "0.0")),
                Double.parseDouble(props.getProperty("forestCover", "0.0")),
                Double.parseDouble(props.getProperty("humanDisturbance", "0.0")),
                species,
                Long.parseLong(props.getProperty("lastSimulatedTick", "0")),
                Double.parseDouble(props.getProperty("recoveryState", "0.0"))
        );
    }

    private static double clamp(double value, double min, double max) {
        if (Double.isNaN(value)) {
            return min;
        }
        return Math.max(min, Math.min(max, value));
    }

    private static double clampPopulation(double value) {
        return clamp(Math.max(0.0, value), 0.0, 1_000_000_000.0);
    }

    private static Map<String, Double> normalizePopulations(Map<String, Double> source) {
        if (source == null || source.isEmpty()) {
            return Collections.emptyMap();
        }
        Map<String, Double> normalized = new LinkedHashMap<>();
        source.forEach((name, value) -> normalized.put(name, clampPopulation(value)));
        return normalized;
    }
}
