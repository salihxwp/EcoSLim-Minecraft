package com.ecosim.common.species;

import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.Objects;
import java.util.Set;

public record SpeciesDefinition(
        String id,
        String name,
        TrophicRole trophicRole,
        Set<String> foodPreferences,
        double foodRequirement,
        double waterRequirement,
        double reproductionRate,
        double mortalityRate,
        double habitatSuitability,
        double localPopulationCapacity,
        double migrationRate,
        double dispersalDistance,
        double diseaseSusceptibility,
        double growthBias
) {
    public SpeciesDefinition {
        Objects.requireNonNull(id, "Species id is required");
        Objects.requireNonNull(name, "Species name is required");
        Objects.requireNonNull(trophicRole, "Trophic role is required");
        if (id.isBlank()) {
            throw new IllegalArgumentException("Species id cannot be blank");
        }
        if (name.isBlank()) {
            throw new IllegalArgumentException("Species name cannot be blank");
        }
        if (localPopulationCapacity <= 0.0) {
            throw new IllegalArgumentException("Local population capacity must be positive");
        }
        foodPreferences = foodPreferences == null ? Collections.emptySet() : new LinkedHashSet<>(foodPreferences);
        foodRequirement = clamp(foodRequirement, 0.0, 1.0);
        waterRequirement = clamp(waterRequirement, 0.0, 1.0);
        reproductionRate = clamp(reproductionRate, 0.0, 1.0);
        mortalityRate = clamp(mortalityRate, 0.0, 1.0);
        habitatSuitability = clamp(habitatSuitability, 0.0, 1.0);
        migrationRate = clamp(migrationRate, 0.0, 1.0);
        dispersalDistance = clamp(dispersalDistance, 0.0, 1000.0);
        diseaseSusceptibility = clamp(diseaseSusceptibility, 0.0, 1.0);
        growthBias = clamp(growthBias, -1.0, 1.0);
    }

    public enum TrophicRole {
        PRODUCER,
        HERBIVORE,
        OMNIVORE,
        PREDATOR,
        POLLINATOR
    }

    public String namespaceId() {
        return "ecosim:" + id;
    }

    private static double clamp(double value, double min, double max) {
        if (Double.isNaN(value)) {
            return min;
        }
        return Math.max(min, Math.min(max, value));
    }
}
