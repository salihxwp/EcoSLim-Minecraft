package com.ecosim.common;

import com.ecosim.common.model.HabitatState;
import com.ecosim.common.model.RegionId;
import com.ecosim.common.species.SpeciesDefinition;
import com.ecosim.common.species.SpeciesRegistry;
import com.ecosim.common.simulation.SimulationConfig;
import com.ecosim.common.simulation.SimulationEngine;
import org.junit.jupiter.api.Test;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.SplittableRandom;

import static org.junit.jupiter.api.Assertions.*;

class SimulationEngineTest {
    private final SpeciesRegistry registry = SpeciesRegistry.defaultRegistry();

    @Test
    void regionCoordinatesUseFloorDivisionForNegativeBlockPositions() {
        RegionId id = RegionId.fromWorldBlock(-1, -64);
        assertEquals(-1, id.x());
        assertEquals(-1, id.z());
    }

    @Test
    void populationNeverBecomesNegative() {
        HabitatState state = new HabitatState(new RegionId(0, 0), 55.0, 0.8, 0.7, 0.8, 0.1,
                Map.of("rabbit", 25.0, "deer", 12.0, "fox", 8.0, "wolf", 4.0, "wild_bee", 30.0), 0L, 0.2);
        SimulationEngine engine = new SimulationEngine();
        HabitatState next = engine.step(state, registry, 200L);
        assertTrue(next.populationFor("rabbit") >= 0.0);
        assertTrue(next.populationFor("deer") >= 0.0);
        assertTrue(next.populationFor("fox") >= 0.0);
        assertTrue(next.populationFor("wolf") >= 0.0);
    }

    @Test
    void populationsRemainBounded() {
        HabitatState state = new HabitatState(new RegionId(0, 0), 80.0, 0.9, 0.7, 0.9, 0.1,
                Map.of("rabbit", 999.0, "deer", 500.0, "fox", 150.0, "wolf", 80.0), 0L, 0.6);
        SimulationEngine engine = new SimulationEngine(SimulationConfig.defaults());
        HabitatState next = engine.step(state, registry, 200L);
        assertTrue(next.populationFor("rabbit") <= registry.get("rabbit").localPopulationCapacity() * SimulationConfig.defaults().populationCapScale());
        assertTrue(next.populationFor("deer") <= registry.get("deer").localPopulationCapacity() * SimulationConfig.defaults().populationCapScale());
        assertTrue(next.populationFor("fox") <= registry.get("fox").localPopulationCapacity() * SimulationConfig.defaults().populationCapScale());
        assertTrue(next.populationFor("wolf") <= registry.get("wolf").localPopulationCapacity() * SimulationConfig.defaults().populationCapScale());
    }

    @Test
    void vegetationGrowsTowardCapacity() {
        HabitatState state = new HabitatState(new RegionId(1, 1), 10.0, 0.9, 0.6, 0.5, 0.1,
                Map.of("rabbit", 8.0, "deer", 4.0, "wild_bee", 10.0), 0L, 0.0);
        SimulationEngine engine = new SimulationEngine();
        HabitatState next = engine.step(state, registry, 200L);
        assertTrue(next.vegetationBiomass() > state.vegetationBiomass());
        assertTrue(next.vegetationBiomass() <= 100.0);
    }

    @Test
    void grazingReducesVegetation() {
        HabitatState state = new HabitatState(new RegionId(1, 2), 90.0, 0.7, 0.8, 0.9, 0.0,
                Map.of("rabbit", 200.0, "deer", 50.0), 0L, 0.3);
        SimulationEngine engine = new SimulationEngine();
        HabitatState next = engine.step(state, registry, 200L);
        assertTrue(next.vegetationBiomass() < state.vegetationBiomass());
    }

    @Test
    void predatorPopulationRespondsToPreyAvailability() {
        HabitatState state = new HabitatState(new RegionId(2, 2), 80.0, 0.8, 0.8, 0.9, 0.0,
                Map.of("rabbit", 120.0, "deer", 130.0, "fox", 10.0, "wolf", 8.0), 0L, 0.5);
        SimulationEngine engine = new SimulationEngine();
        HabitatState next = engine.step(state, registry, 200L);
        assertTrue(next.populationFor("fox") >= state.populationFor("fox"));
    }

    @Test
    void preyPopulationRespondsToPredation() {
        HabitatState state = new HabitatState(new RegionId(0, 1), 70.0, 0.7, 0.7, 0.8, 0.0,
                Map.of("rabbit", 90.0, "deer", 90.0, "fox", 30.0, "wolf", 20.0), 0L, 0.4);
        SimulationEngine engine = new SimulationEngine();
        HabitatState next = engine.step(state, registry, 200L);
        assertTrue(next.populationFor("rabbit") <= state.populationFor("rabbit") + 1.0);
        assertTrue(next.populationFor("deer") <= state.populationFor("deer") + 1.0);
    }

    @Test
    void migrationConservesPopulationWhenNoBirthsOrDeathsOccur() {
        Map<String, Double> populations = new LinkedHashMap<>();
        populations.put("rabbit", 100.0);
        populations.put("deer", 40.0);
        Map<String, Double> migrated = SimulationEngine.migratePopulation(populations, 0.25, new SplittableRandom(7L));
        double before = populations.values().stream().mapToDouble(Double::doubleValue).sum();
        double after = migrated.values().stream().mapToDouble(Double::doubleValue).sum();
        assertEquals(before, after, 1e-6);
    }

    @Test
    void serializationRoundTripsPreserveData() {
        HabitatState original = new HabitatState(new RegionId(-5, -6), 33.5, 0.7, 0.6, 0.2, 0.8,
                Map.of("rabbit", 12.0, "wolf", 2.0), 42L, 0.55);
        Properties props = original.toProperties();
        HabitatState loaded = HabitatState.fromProperties(props);
        assertEquals(original.regionId(), loaded.regionId());
        assertEquals(original.vegetationBiomass(), loaded.vegetationBiomass(), 0.0001);
        assertEquals(original.populationFor("rabbit"), loaded.populationFor("rabbit"), 0.0001);
        assertEquals(original.lastSimulatedTick(), loaded.lastSimulatedTick());
    }

    @Test
    void simulationIsDeterministicForFixedSeedAndInput() {
        HabitatState state = new HabitatState(new RegionId(3, 3), 60.0, 0.8, 0.7, 0.6, 0.2,
                Map.of("rabbit", 50.0, "deer", 30.0, "fox", 12.0, "wolf", 6.0, "wild_bee", 40.0), 0L, 0.4);
        SimulationEngine first = new SimulationEngine(SimulationConfig.defaults(), 42L);
        SimulationEngine second = new SimulationEngine(SimulationConfig.defaults(), 42L);
        HabitatState a = first.step(state, registry, 200L);
        HabitatState b = second.step(state, registry, 200L);
        assertEquals(a.vegetationBiomass(), b.vegetationBiomass(), 0.0001);
        assertEquals(a.populationFor("rabbit"), b.populationFor("rabbit"), 0.0001);
    }

    @Test
    void invalidSpeciesDefinitionsAreRejected() {
        assertThrows(IllegalArgumentException.class, () -> new SpeciesDefinition("bad-id", "Bad", SpeciesDefinition.TrophicRole.HERBIVORE,
                Set.of("grass"), 0.3, 0.4, 0.2, 0.1, 0.9, 0.0, 0.1, 1.0, 0.2, 0.0));
    }

    @Test
    void largePopulationAndLongIntervalsDoNotOverflow() {
        HabitatState state = new HabitatState(new RegionId(0, 0), 95.0, 0.9, 0.9, 0.9, 0.0,
                Map.of("rabbit", 1_000_000.0, "deer", 900_000.0, "fox", 120_000.0, "wolf", 80_000.0), 0L, 0.8);
        SimulationEngine engine = new SimulationEngine();
        HabitatState next = engine.step(state, registry, 10_000L);
        assertFalse(Double.isInfinite(next.populationFor("rabbit")));
        assertFalse(Double.isNaN(next.populationFor("rabbit")));
        assertTrue(next.populationFor("rabbit") >= 0.0);
    }
}
